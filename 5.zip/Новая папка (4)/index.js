// 
let son = prompt("Biror son kiriting:");
if (son % 2 === 0) {
    alert(son + " - juft son");
} else {
    alert(son + " - toq son");
}



// 
let a = +prompt("Birinchi sonni kiriting:");
let b = +prompt("Ikkinchi sonni kiriting:");
if (a > b) {
    alert("Kattasi: " + a);
} else if (b > a) {
    alert("Kattasi: " + b);
} else {
    alert("Sonlar teng");
}




// 
let tugilganYil = prompt("Tug'ilgan yilingizni kiriting:");
let joriyYil = new Date().getFullYear();
let yosh = joriyYil - tugilganYil;
alert("Sizning yoshingiz: " + yosh);




// 
let x = +prompt("1-sonni kiriting:");
let y = +prompt("2-sonni kiriting:");
let z = +prompt("3-sonni kiriting:");
let engKatta = Math.max(x, y, z);
alert("Eng katta son: " + engKatta);



// 
let n1 = +prompt("Birinchi son:");
let amal = prompt("Amalni kiriting (+, -, *, /):");
let n2 = +prompt("Ikkinchi son:");

if (amal === '+') alert(n1 + n2);
else if (amal === '-') alert(n1 - n2);
else if (amal === '*') alert(n1 * n2);
else if (amal === '/') alert(n1 / n2);
else alert("Noto'g'ri amal kiritildi!");





// 
let n = +prompt("n sonini kiriting:");
let yigindi = 0;
for (let i = 1; i <= n; i++) {
    yigindi += i;
}
alert("1 dan " + n + " gacha bo'lgan sonlar yig'indisi: " + yigindi);




// 
let son2 = +prompt("Qaysi son uchun ko'paytirish jadvali kerak?");
let natija = "";
for (let i = 1; i <= 10; i++) {
    natija += son2 + " * " + i + " = " + (son2 * i) + "\n";
}
alert(natija);




